==================
Graph Motif Models
==================

This package provides a basic framework and supporting functionality for generating network structure network structure using graph motifs.

The paper in support of this method is currently unpublished and is a working draft, but is available from the author upon request.

This package is written on top of NetworkX, a Python package for the creation, manipulation, and study of the structure, dynamics, and functions of complex networks.  To download this package, see http://networkx.lanl.gov/.

To use the GMM package, :
    
    #!/usr/bin/env python
    
    from gmm import *

Contact
=======

 - Author:  Drew Conway
 - Email:   drew.conway@nyu.edu
 - Date:    2011-04-22

